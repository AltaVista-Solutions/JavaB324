import java.util.Scanner;

public class DoWhileLoop1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter a Value:");
		int n=sc.nextInt();
		
		int i=1;
		do {
			System.out.println(i);
			i++;
		}
		while(i<=n);

	}

}
