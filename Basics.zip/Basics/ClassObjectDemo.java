class Employee
{
	public int Id;
	public String Name;
	public String Designation;
	
	public void PrintEmployee()
	{
		System.out.println(Id+"-"+Name+"-"+Designation);
	}
}
public class ClassObjectDemo {

	public static void main(String[] args) {
		Employee emp1=new Employee();
		emp1.Id=9001;
		emp1.Name="Shivaji";
		emp1.Designation="Developer";
		emp1.PrintEmployee();
		
		Employee emp2=new Employee();
		emp2.Id=9002;
		emp2.Name="John";
		emp2.Designation="Tester";
		emp2.PrintEmployee();
	}

}
