class Sample implements IArithematic
{

	@Override
	public void sum(int x, int y) {
		System.out.println(x+y);
		
	}

	@Override
	public void sub(int x, int y) {
		System.out.println(x-y);
		
	}
	
}
public class InterfacesDemo {

	public static void main(String[] args) {
		IArithematic s1=new Sample();
		s1.sum(10, 20);
		s1.sub(10, 20);

	}

}
