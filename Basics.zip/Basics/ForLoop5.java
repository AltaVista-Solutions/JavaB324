import java.util.Scanner;

public class ForLoop5 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter n value:");
		int n=sc.nextInt();
		for(int i=1;i<=10;i++)
		{
//			System.out.print(n);
//			System.out.print(" X ");
//			System.out.print(i);
//			System.out.print(" = ");
//			System.out.print(n*i);
//			System.out.print("\n");
			System.out.println(n+" X "+i+" = "+n*i);
		}

	}

}
