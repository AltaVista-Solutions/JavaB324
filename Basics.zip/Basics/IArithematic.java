
public interface IArithematic 
{
	void sum(int x,int y);
	void sub(int x,int y);
}
