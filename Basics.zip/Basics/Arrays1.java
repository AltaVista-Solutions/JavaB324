
public class Arrays1 {

	public static void main(String[] args) {
		int[] scores= {95,85,69,87,98,99};
		for(int i=0;i<scores.length;i++)
		{
			System.out.println(scores[i]);
		}

	}

}
