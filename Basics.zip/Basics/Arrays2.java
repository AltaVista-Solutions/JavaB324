
import java.util.*;
public class Arrays2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array Size:");
		int n=sc.nextInt();
		
		String[] courselist=new String[n];
		
		//reading array-values
		for(int i=0;i<courselist.length;i++)
		{
			System.out.println("Enter Value For Index-"+i+":");
			courselist[i]=sc.next();
		}
		
		Arrays.sort(courselist);
		
		//printing array-values
		for(int i=0;i<courselist.length;i++)
		{
			System.out.println(courselist[i]);
		}
		
	
	}

}
