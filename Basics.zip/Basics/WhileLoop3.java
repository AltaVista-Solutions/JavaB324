import java.util.Scanner;

public class WhileLoop3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter a Value:");
		int a=sc.nextInt();
		
		System.out.println("Enter b Value:");
		int b=sc.nextInt();

		boolean x=true;
		
		while(x==true)
		{
			System.out.println("1.Add\n2.Sub\n3.Mul\n0.Exit\nEnter Your choice:");
			int n=sc.nextInt();
			
			switch(n)
			{
				case 1:
					System.out.println(a+b);
					break;
				case 2:
					System.out.println(a-b);
					break;
				case 3:
					System.out.println(a*b);
					break;
				case 0:
					x=false;
					break;
				default:
					System.out.println("Wrong Input!");
					break;
			}
		}
	}

}
