import java.util.Scanner;

public class WhileLoop2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter n value:");
		int n=sc.nextInt();
		
		int i=n;
		while(i>=1)
		{
			System.out.println(i);
			i--;
		}

	}

}
