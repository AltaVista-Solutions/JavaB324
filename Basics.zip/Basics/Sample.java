
public class Sample {

	public static void main(String[] args) {
		int a=15,b=19;
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
		
		System.out.println(a>b);
		System.out.println(a>=b);
		System.out.println(a<b);
		System.out.println(a<=b);
		System.out.println(a==b);
		System.out.println(a!=b);
		
		System.out.println(true && true);
		System.out.println(true && false);
		System.out.println(false && true);
		System.out.println(false && false);
		
		int i=100,j=15,k=5;
		if(i>j && i>k)
		{
			System.out.println(i+" is Bigger");
		}
		
		System.out.println(true || true);
		System.out.println(true || false);
		System.out.println(false || true);
		System.out.println(false || false);
		
		System.out.println(!true);
		System.out.println(!false);
		
		int e=10,f=19;
		e=f;
		System.out.println(e);
		System.out.println(f);
		
		e+=1;
		System.out.println(e);
		
		e-=1;
		System.out.println(e);
		
		e*=10;
		System.out.println(e);
		
		e/=2;
		System.out.println(e);
		
		e%=2;
		System.out.println(e);
		
		System.out.println(true?"ok":"Not Ok");
		System.out.println(false?"ok":"Not Ok");
		int h=16,g=19;
		System.out.println(h>g?"Bigger":"smaller");
		
		int x=10;
		x++;
		System.out.println(x);
		++x;
		System.out.println(x);
		
		int y=10;
		y--;
		System.out.println(y);
		--y;
		System.out.println(y);
	}

}
